DSI - FVRT Submission 
KC TechWeek - Hackathon Submission - Sept 20th 2015 

Team Members: 
Joel Stephens
Shakthi Nadivada 
Dale Schalow 
Kelly Luck 
Rohit Chaube


Modules:
1. Arduino.exe, gets acceleration, direction information from bike.
2. Unity 3D, Create 3D model for bike routes and reads data from Arduino to update UI.
3. Cerner API used to push/pull observation data
4. File watcher application, monitors the directory/file for observation data and uploads the content to Cerner using FHIR APIs.
5. Web application, provides ability for users to track their session details


Execution:
1. Connect Arduino controls to bike and computer
2. Run Unit 3D application
3. Run FileWatcher.exe
4. Start biking
5. press esc once session is complete
6. Log into web application to see the result for completed session.